# AGENTS.md Guidance for Future Project Roots

## Shared knowledge

Before beginning a substantial ML/AI task, read `/home/admin/facktry/docs/SHARED_KNOWLEDGE.md` completely. Treat it as a cross-project ML/AI engineering reference. It contains durable lessons about data, training, prompting, evaluation, reproducibility, privacy, infrastructure, and serving. Keep it updated when a future experiment produces a durable lesson.

### Shared-knowledge update directions

After any non-trivial ML/AI task, decide whether it produced knowledge that will help a future ML/AI task. Add only durable, evidence-backed guidance:

- Record repeatable failure modes, validated fixes, reliable workflows, invariants, and evaluation or privacy lessons—not a transcript of the session.
- Write the transferable principle first. Ensure it can apply across models, datasets, modalities, training methods, agents, and deployment tasks; put project-specific examples, paths, or model names afterward under a clearly labeled case-study subsection.
- For each lesson, state the problem, the evidence or measurable observation, the consequence, and the preventive action or check. Include modality-specific details only when they clarify a broader principle.
- Preserve reproducibility: include relevant configuration choices, tool/version constraints, thresholds, and commands only when they remain useful and are verified.
- Update the relevant section instead of creating contradictory duplicates. Keep entries concise, skimmable, and organized by principle or workflow.
- Never add passwords, API keys, private SMS, raw prompts containing sensitive data, customer identifiers, secrets, or unnecessary host details. Summarize sensitive findings at an aggregate level.
- Do not promote guesses, one-off symptoms, or unverified model behavior to shared knowledge. Mark hypotheses explicitly and replace them when tested.
- When a lesson becomes obsolete, revise or remove it and preserve the reason for the change when useful.
