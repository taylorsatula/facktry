# Shared Knowledge: ML/AI Engineering

This document records durable, evidence-backed lessons from local ML/AI work. The SMS voice project is a concrete case study, not the scope of the document. The principles below should apply to language, vision, multimodal, preference-optimization, evaluation, and serving tasks unless a project-specific exception is stated.

## Reliability objective

A successful experiment is not merely the run with the lowest validation loss. A useful model and system should:

- solve the intended task correctly;
- use only evidence available in its input and authorized external state;
- fail or ask for clarification when required information is absent;
- preserve important capabilities outside the tuned domain;
- behave consistently across prompts, seeds, contexts, and decoding settings;
- avoid privacy, security, and operationally consequential fabrications; and
- pass predefined, reproducible release gates.

Optimize the model, data, prompt/interface, and serving policy together. A model can have good loss and poor deployment behavior when any of those layers is misaligned.

## General failure modes

### Distribution collapse and self-distillation

Continuing training from a specialized adapter on outputs produced by that same adapter amplifies its strongest quirks. This can look like forgetting even when the frozen base retains the capability. Start a corrective experiment from an explicitly preserved ancestor, add broad replay, and compare against the frozen base.

### Hidden-context mismatch

If a generator or evaluator sees a scenario brief, tool result, label, retrieval context, or state field that the trained model does not see, the target may contain unsupported facts. Every fact required to produce a target must be visible in the training input or represented by an authorized interface available at inference.

### Context and split leakage

Large row counts do not imply useful diversity. Measure unique inputs, unique final turns, template/context families, semantic near-duplicates, and train/eval overlap. Split at the unit that carries dependence: thread, customer, document, subject, scene, or template—not merely at individual rows.

### Quality metrics that do not control selection

A score is not a filter unless it changes which records or checkpoints are retained. Distributional metrics can indicate drift but cannot by themselves judge grounding, correctness, relevance, or human preference. Keep hard correctness/privacy gates separate from soft distributional diagnostics.

### Prompt/interface entanglement

System prompts, role labels, mode tokens, tool-state text, and serialization formats are part of the model's learned distribution. Changing them between training and serving can cause role lock-in, refusals, or irrelevant domain activation. Keep the interface canonical, vary incidental wording when appropriate, and keep safety instructions concise enough not to become the style.

### Over-specialization

A domain-heavy corpus can turn a style or task adapter into a narrow world model. Balance by domain, task/action, length, and interaction type. Include out-of-domain capability replay, ambiguity, topic pivots, and deliberately unknown-state cases.

### Safety-style conflation

A model can become safe but unnatural if every target and prompt uses policy language. Put machine-checkable safety and tool authorization in the interface/serving layer where possible. Train natural responses to missing information rather than long refusals or policy explanations.

## Data and privacy principles

- Keep private data local and minimize its lifetime in memory.
- Redact direct identifiers before model use; never write raw or unnecessarily identifying examples into artifacts, logs, prompts, or preference pairs.
- Store aggregate provenance, hashes, counts, and policy descriptions instead of private text.
- Preserve attribution: a target should be paired with the correct preceding input and state.
- Separate public/fictional, private, synthetic, replay, preference, train, development, and sealed-test sources in manifests.
- Use deterministic seeds and record the transformation policy.
- Treat synthetic data as a coverage tool, not evidence of human quality.
- For generated data, make the world state explicit, validate factual claims against it, reject unsupported actions, and generate more candidates than are selected.

## Training and adapter principles

- Preserve base models and every adapter. Train corrective work in a new run directory.
- Prefer conservative adaptation until a complete evaluation suite shows that stronger steering is needed.
- Target only the modules and capacity required for the task before expanding the adapter.
- Balance domain data with general/task replay and measure capability retention against the frozen base.
- Use target-only loss when the goal is response behavior; do not accidentally train prompt boilerplate as the answer.
- Track effective examples, optimizer steps, repeated-example exposure, target lengths, and checkpoint metrics.
- Do not choose a checkpoint from one validation loss. Use hard release gates and a multi-metric comparison.

## Preference optimization

Ordinary SFT teaches likelihood; it does not explicitly teach that one valid response is preferable to polished but unnatural, evasive, verbose, or tool-hallucinating alternatives.

Preference pairs should use:

- a chosen response with a defensible source or explicit rubric;
- a rejected response that demonstrates a concrete error or undesirable style;
- the identical visible input and state for both responses;
- held-out subjects/templates for evaluation; and
- a conservative update from a preserved reference model.

Report preference accuracy/margin, but also rerun task correctness, grounding, privacy, capability-retention, diversity, and deployment tests. A preference objective can improve style while degrading factuality or coverage.

## Prompt and tool-state principles

Represent external facts and permissions structurally when possible. Distinguish:

- information known from the input;
- information retrieved from an authorized tool;
- actions merely requested by the user; and
- actions actually executed and confirmed by a tool.

The model must not claim to have searched, booked, sent, called, changed, purchased, or completed something merely because it can write that sentence. Serving checks and tool results should enforce this independently of model wording.

Use explicit modes or task metadata when the deployment has materially different behaviors, but test automatic mode inference and transitions. Prompt variants can prevent accidental dependence on one phrase or persona token; they do not replace data diversity.

## Evaluation and release gates

Freeze the evaluation suite before generating a new training corpus. Use identical prompts, seeds, decoding settings, and state for base, ancestor, candidate, and deployed-wrapper comparisons.

Report separately:

- task/action correctness;
- unsupported claim and hallucinated-state rates;
- abstention, clarification, and false-refusal rates;
- capability retention outside the target domain;
- robustness across context length, prompt variants, and decoding temperatures;
- privacy/memorization failures;
- preference win rate and margin;
- style or distribution distance to trusted human/reference data;
- repetition, duplicate, and semantic diversity;
- raw model failures versus guarded production failures; and
- resource use, latency, and memory headroom.

Do not hide raw failures behind a wrapper metric. If a serving guard is required, test and document it as part of the deployed system, while retaining the unguarded model measurement.

## Reusable trajectory-validation fixture

Multi-turn self-play and LLM oversight are validation capabilities, not necessarily experiments. Keep the controller, trajectory schema, deterministic analyzers, batch judge, corpus-level overseer, calibration fixtures, and release aggregation in reusable package infrastructure. The calling experiment should own scenarios, criteria, run artifacts, manifests, and promotion decisions.

Assess batches of complete trajectories rather than one transcript per judge context. Use deterministic checks before LLM judging, pass the caller's explicit criteria into every judge prompt, and give an overseer aggregate batch summaries plus recurring-pattern evidence. Preserve replay mode so a new rubric can be applied to old trajectories without changing the sampled population. Keep private simulator state out of subject prompts and persisted trajectory artifacts.

A faux-human may be another model, not only a scripted simulator. Give it structured control: model/configuration identity, engagement length, per-turn instructions, targeted pain points, and a visible stop sequence. Tell it exactly when to emit the stop sequence, but retain a hard runner-side turn cap because models may ignore control tokens. Assess simulator realism separately when its generated turns could contaminate subject conclusions.

## Serving and operational principles

- Treat model, prompt template, tokenizer, adapter, tool-state schema, decoder, and output guard as one versioned release.
- Use local/offline assets when privacy or reproducibility requires it.
- Do not run mutually exclusive large model services on the same GPUs.
- Before long jobs, validate paths, environment, GPU assignment, disk space, and rollback/preservation conditions.
- Prefer quiet redirected logs; retain summaries, errors, metrics, and hashes.
- Add retries only for bounded, classifiable failures. A fallback should be short, truthful, and non-destructive.
- Test multi-turn trajectories, not only isolated prompts. Local conversational loops can cause behavior that is absent in single-turn evaluation.

## Case study: SMS business voice

The first two adapters demonstrated the general failure modes above. A teacher continuation trained on narrow synthetic service data became a self-distilled service persona. Synthetic records had hidden scenario context, few distinct histories, and quality scores that did not actually filter selection. Proactive messages were mislabeled as ordinary replies. The result was service fixation, invented appointments/actions, weak pivots, and repeated uncertainty.

The robust SFT correction used a fresh adapter from the base, immediate-turn attribution, domain balancing, visible fictional state, multiple business domains, general/casual replay, and varied system-role wording. The real corpus was redacted and consumed in memory. The robust adapter was evaluated with hard grounding/privacy/pivot checks before serving.

The subsequent style pass used human redacted SMS replies as chosen DPO responses and robust-adapter continuations as rejected responses for identical visible prompts. It used a frozen reference adapter, low learning rate (`5e-6`), beta `0.1`, and a limited 120-step run.

Verified DPO run:

- path: `runs/voice-qwen35-9b-robust-dpo-v3-20260806T0600Z/`;
- 412 training preference pairs and 63 held-out pairs;
- held-out preference accuracy: 96.875%;
- held-out preference margin: 2.218;
- DPO loss: 0.691 initial to 0.557 final;
- private preference text was memory-only;
- the preceding robust adapter remained hash-unchanged.

Current deployed case-study adapter:

`runs/voice-qwen35-9b-robust-dpo-v3-20260806T0600Z/artifacts/policy_adapter/`

The serving layer uses explicit business state, prompt variants, unsupported-action detection, greedy retry, and a short safe fallback. The unguarded candidate still has measurable out-of-domain/service-language failures, so both raw and guarded metrics must remain visible in future comparisons.

### Case-study update: target-shape audit and grounded generation

A later audit of the real local corpus found 449 threads and 6,173 messages: customer messages had a median of 9 words, business replies 19 words, and 176 threads exceeded 10 messages. Scheduling appeared in 413 threads, service scope in 435, uncertainty/change in 389, casual/personal pivots in 305, pricing/payment in 175, and logistics in 158. These categories overlap. The consequence is that a one-shot quote/scheduling corpus is not a sufficient proxy for the target; data must represent terse customer turns, longer business replies, repeated follow-ups, logistics, changes of mind, and topic pivots.

Synthetic generation should be gated before training. A first fictional grounded generator produced 800 candidates in parallel (400 per GPU), but a deterministic filter accepted only 33 because authored histories sometimes ended with a customer turn and the generator appended another customer turn. This was a schema-construction failure, not a model-quality result. Prevent it by validating role alternation at scenario construction time, then measuring rejection reasons, family balance, train/eval split counts, context uniqueness, and grounding failures before launching a GPU training run.

For corrective synthetic data, use a frozen base teacher by default rather than the specialized deployed adapter. The latter can self-distill its repetition, refusal, or service-fixation quirks into the next adapter. Keep every generated fact in the visible conversation or verified state, use fictional scenario metadata, and retain only aggregate provenance in artifacts. Raw private SMS may be read locally in memory for aggregate target-shape analysis or redacted real-example training; fictional generation does not need elaborate PII processing when it never contains private data. The practical boundary is local-only raw access plus no raw text in logs, artifacts, or remote requests.

The efficient workflow is: construct and validate scenarios, generate a bounded multi-GPU candidate batch, filter deterministically, inspect coverage and rejection causes, run a short fresh-base LoRA smoke, and only then consider a long run. Parallel generation must use deterministic global candidate indices and per-part manifests so outputs can be merged and audited without changing the sampled population.

## Generalized experiment checklist

1. Define the task, authorized evidence/state, failure costs, and release gates before changing data or weights.
2. Identify and hash the immutable starting model/adapter; never overwrite an ancestor.
3. Audit attribution, source mixture, domain/task balance, lengths, duplicate contexts, and split leakage.
4. Verify training and inference serialization, prompt, mode, tool-state, and tokenizer compatibility.
5. Ensure synthetic or generated targets depend only on visible/authorized input.
6. Train a conservative new run and preserve checkpoints and aggregate provenance.
7. Compare base, ancestor, candidate, and deployed wrapper on the same sealed tests.
8. Exercise realistic multi-step trajectories, ambiguity, missing state, pivots, and adversarial inputs.
9. Inspect raw and guarded failures, then promote only when all hard gates pass.
10. Record durable, measurable lessons from the experiment without storing sensitive examples.

## Local execution reference

- The local training environment is `/home/admin/dft-eval-harness/.venv312/bin/python` with offline Hugging Face assets.
- On this host, training normally uses GPU 1 while the local chat server uses GPU 0 when possible.
- Before Vast.ai provisioning, configuration, debugging, or destruction, follow `/home/admin/BABYS_FIRST_VAST_ML_ENGINEER.md` completely.
