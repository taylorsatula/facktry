# Skill: Elicit a MissionBrief

Use this skill before freezing or running **any** facktry objective or experiment, including a data investigation that will not touch weights.

## Contract

Natural-language intent is not an executable objective. Complete the following loop:

```text
human mission
  → adaptive questions
  ↔ research between volleys when useful
  → human approves each proposed hard gate
  → save_mission_brief
  → freeze_objective
```

The working draft may remain in the Pi session during elicitation. Save the complete dossier once, at the end of elicitation. Do not claim the MissionBrief exists until `save_mission_brief` succeeds.

## Required outline

Cover each section, using follow-ups and domain-specific branches as needed:

1. Human intent and deliverable
2. Domain, task, and audience
3. The human's success case
4. Failure cases, anti-goals, and must-not-regress behavior
5. Baselines and relevant constraints
6. Data limits, budget, and operating policy
7. Evaluation plan and proposed suites/checkers
8. Proposed hard gates, approved individually by the human

Domain skills may add required sections. This is an outline, not a fixed questionnaire or decision tree. Choose the path that best clarifies the mission; do not silently skip a required section.

## Question and research behavior

- Use `questions` for structured human volleys. Prefer concrete options, but allow detail where the human’s intent needs nuance.
- Use `research` between question volleys when literature, methods, datasets, metrics, or evaluation design can improve the next question or proposal.
- Give research the current mission context, constraints, and unanswered question.
- Research is proposal evidence, never a passed gate and never a substitute for human approval.
- The research worker does not interview the human.

## MissionBrief contents

The saved brief must preserve:

- original mission and accepted answers, including exact prompts and meaningful revisions
- success case, failure cases, anti-goals, baselines, constraints, and evaluation plan
- every proposed hard gate and its individual human approval
- one-line research summaries and references/pointers, with retrieval metadata and research run references
- a content hash, immutable version, parent version when applicable, operator session, and timestamp

Do not copy full paper bodies into the brief. References may be fetched again later.

## Stop conditions

- If a required section is unclear, ask a follow-up or research it; do not invent the human’s intent.
- If the human cancels or a required answer is absent, do not freeze or run an experiment.
- If `save_mission_brief` fails, report the blocker and do not call `freeze_objective`.
- After freeze, a mission change requires a new MissionBrief and a superseding Objective.
